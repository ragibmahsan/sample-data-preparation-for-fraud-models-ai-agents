const { Kafka } = require('kafkajs')
const { generateAuthToken } = require('aws-msk-iam-sasl-signer-js')

const topic = process.env.TOPIC_NAME;
const brokers = process.env.BOOTSTRAP_SERVERS_CONFIG.split(",");
const region = process.env.AWS_REGION;

const kafka = new Kafka({
    clientId: 'fraud--flagging-app',
    brokers: brokers,
    ssl: true,
    sasl: {
        mechanism: 'oauthbearer',
        oauthBearerProvider: () => oauthBearerTokenProvider(region)
    }
})

async function oauthBearerTokenProvider(region) {
    // Uses AWS Default Credentials Provider Chain to fetch credentials
    const authTokenResponse = await generateAuthToken({ region });
    return {
        value: authTokenResponse.token
    }
}

function getEventTimestamp(){
    var tzoffset = (new Date()).getTimezoneOffset() * 60000;
    var localISOTime = (new Date(Date.now() - tzoffset)).toISOString();
    return localISOTime;
}

exports.handler = async (event, context) =>{
    let responseData = {};
    try {

        const producer = kafka.producer();
        await producer.connect();

        let flaggedTxs = [];
        let tx = JSON.stringify({
            event_timestamp: getEventTimestamp(),
            entity_id: "397-96-6634",
            billing_city: "Delco",
            billing_state: "NC",
            billing_zip: "28436"
        });
            
        await producer.send({
            topic: topic,
            messages: [ { value: tx } ]
        });
            
        flaggedTxs.push(tx);

        await producer.disconnect();

        responseData = { 
            transactions: flaggedTxs
        };

        console.log("The following transactions were flagged: " + responseData);
        return responseData;

    }catch(error){  
        responseData = { 
            Error: 'Error flagging transactions'
        };
        console.log(responseData['Error'] + ', error: ' + error);
        return responseData;
    }
};