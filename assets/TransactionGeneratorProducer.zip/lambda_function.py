import boto3
import csv
import json
import os
import socket
import datetime

from kafka import KafkaProducer
from kafka.errors import KafkaError
from aws_msk_iam_sasl_signer import MSKAuthTokenProvider

#######################
# ENVIRONEMNT VARIABLES
#######################
S3_BUCKET = os.environ['S3_BUCKET']
S3_KEY = os.environ['S3_KEY']
KAFKA_BOOTSTRAP_SERVERS = os.environ['KAFKA_BOOTSTRAP_SERVERS']
KAFKA_TOPIC = os.environ['KAFKA_TOPIC']
REGION = os.environ['AWS_REGION']

#######################
# GET AUTH TOKEN
#######################
class MSKTokenProvider():

    def token(self):
        token, _ = MSKAuthTokenProvider.generate_auth_token(REGION)
        return token

tp = MSKTokenProvider()

#######################
# INITIALIZING CLIENTS
#######################
s3 = boto3.client('s3')

producer = KafkaProducer(
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS.split(","),
    security_protocol='SASL_SSL',
    sasl_mechanism='OAUTHBEARER',
    sasl_oauth_token_provider=tp,
    client_id=socket.gethostname(),
    value_serializer=lambda m: json.dumps(m).encode('utf8')
)

#######################
# LAMBDA HANDLER
#######################
def lambda_handler(event, context):

    try:
        obj = s3.get_object(Bucket=S3_BUCKET, Key=S3_KEY)
        csvfile = obj['Body'].read().decode('utf-8').splitlines()
        reader = csv.DictReader(csvfile)
        
        for row in reader:
            
            message = {
                "event_timestamp": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "label_name": row['label_name'],
                "event_id": row['event_id'],
                "entity_type": row['entity_type'],
                "entity_id": row['entity_id'],
                "card_bin": row['card_bin'],
                "billing_latitude": row['billing_latitude'],
                "billing_longitude": row['billing_longitude'],
                "billing_country": row['billing_country'],
                "customer_job": row['customer_job'],
                "user_agent": row['user_agent'],
                "product_category": row['product_category'],
                "order_price": row['order_price'],
                "payment_currency": row['payment_currency'],
                "merchant": row['merchant'],
                "ip_address": row['ip_address']
            }

            print(json.dumps(message))
            producer.send(KAFKA_TOPIC, message)

        producer.flush()

        return {
            'statusCode': 200,
            'body': json.dumps('Data processed and published to Kafka topic')
        }

    except Exception as e:
        print("Failed to send message:", str(e))